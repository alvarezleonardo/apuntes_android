package digitalhouse.android.basededatosywebbaseintegrado.util;

public interface ResultListener<T> {
    void finish(T resultado);
}