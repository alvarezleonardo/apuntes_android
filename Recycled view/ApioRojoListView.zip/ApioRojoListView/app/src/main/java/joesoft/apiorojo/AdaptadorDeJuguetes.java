package joesoft.apiorojo;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.List;

/**
 * Created by joe on 10/5/16.
 */
public class AdaptadorDeJuguetes extends BaseAdapter {
    private List<Juguete> listaDeJuguetes;
    private Context unContext;

    public AdaptadorDeJuguetes(Context context, List<Juguete> listaDeJuguetes) {
        this.listaDeJuguetes = listaDeJuguetes;
        this.unContext = context;
    }

    @Override
    public int getCount() {
        return listaDeJuguetes.size();
    }

    @Override
    public Juguete getItem(int i) {
        return listaDeJuguetes.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        Juguete jugueteAMostrar = getItem(i);

        LayoutInflater layoutInflater = (LayoutInflater) unContext.getSystemService(unContext.LAYOUT_INFLATER_SERVICE);
        view = layoutInflater.inflate(R.layout.listview_celda_juguete, viewGroup, false);

        TextView textViewNombre = (TextView) view.findViewById(R.id.textViewNombreJuguete);
        TextView textViewPlatita = (TextView) view.findViewById(R.id.textViewPrecioJuguete);

        textViewNombre.setText(jugueteAMostrar.getNombre());
        textViewPlatita.setText("$ " + jugueteAMostrar.getPlatita().toString());

        return view;
    }

}













