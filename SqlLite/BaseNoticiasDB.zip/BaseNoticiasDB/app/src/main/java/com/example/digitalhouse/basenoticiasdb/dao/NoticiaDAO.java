package com.example.digitalhouse.basenoticiasdb.dao;

/**
 * Created by digitalhouse on 31/10/16.
 */
public class NoticiaDAO {
}
