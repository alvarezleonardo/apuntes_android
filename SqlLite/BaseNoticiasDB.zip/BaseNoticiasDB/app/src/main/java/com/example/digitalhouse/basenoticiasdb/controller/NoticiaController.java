package com.example.digitalhouse.basenoticiasdb.controller;

/**
 * Created by digitalhouse on 31/10/16.
 */
public class NoticiaController {
}
