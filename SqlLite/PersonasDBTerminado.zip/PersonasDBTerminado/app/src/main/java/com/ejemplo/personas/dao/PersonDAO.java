package com.ejemplo.personas.dao;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.ejemplo.personas.model.Person;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by digitalhouse on 6/06/16.
 */
public class PersonDAO extends SQLiteOpenHelper{

    private static final String DATABASE_NAME = "PersonDB";
    private static final Integer DATABASE_VERSION = 1;
    private static final String TABLE_PERSON = "Persons";
    private static final String ID = "id";
    private static final String NAME = "name";
    private static final String LAST_NAME = "lastName";
    private static final String AGE = "age";
    private static final String LAST_TWEET = "lastTweet";

    public PersonDAO(Context context) {
        //CONSTRUYE UNA BD SQLITE CON NOMBRE PERSONDB
        super(context,DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase database) {

        //CREAR LA TABLA PERSONAS
        String createTablePersonas =
                        "CREATE TABLE " + TABLE_PERSON + "(" +
                        ID + " INTEGER PRIMARY KEY, " +
                        NAME + " TEXT, " +
                        LAST_NAME + " TEXT, " +
                        AGE + " INTEGER, " +
                        LAST_TWEET + " TEXT" + ")";

        database.execSQL(createTablePersonas);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }

    public void addPersonToDatabase(Person person){

        ContentValues row = new ContentValues();
        row.put(ID, person.getId());
        row.put(NAME, person.getName());
        row.put(LAST_NAME, person.getLastName());
        row.put(AGE, person.getAge());
        row.put(LAST_TWEET, person.getLastTweet());

        SQLiteDatabase database = getWritableDatabase();
        database.insert(TABLE_PERSON, null, row);

        database.close();
    }

    public Person getPersonFromDB(Integer id){

        Person person = null;
        SQLiteDatabase database = getReadableDatabase();

        //"SELECT * FROM TABLE_PERSONAS WHERE ID = id"
        String selectQuery = "SELECT * FROM " + TABLE_PERSON
                + " WHERE " + ID + "=" + id;

        Cursor cursor = database.rawQuery(selectQuery, null);

        if(cursor.moveToNext()){
            person = getPerson(cursor);
        }

        cursor.close();
        database.close();
        return person;
    }

    public List<Person> getPersonsFromDatabase(){

        SQLiteDatabase database = getReadableDatabase();
        List<Person> personList = new ArrayList<>();
        //SELECT * FROM TABLE_PERSON
        String selectQuery = "SELECT * FROM " + TABLE_PERSON;

        Cursor cursor = database.rawQuery(selectQuery, null);

        while( cursor.moveToNext()){

            Person person = getPerson(cursor);
            personList.add(person);
        }

        cursor.close();
        database.close();
        return personList;
    }


    private Person getPerson(Cursor cursor){

        Person person = new Person();
        person.setId(cursor.getInt(cursor.getColumnIndex(ID)));
        person.setName(cursor.getString(cursor.getColumnIndex(NAME)));
        person.setLastName(cursor.getString(cursor.getColumnIndex(LAST_NAME)));
        person.setAge(cursor.getInt(cursor.getColumnIndex(AGE)));
        person.setLastTweet(cursor.getString(cursor.getColumnIndex(LAST_TWEET)));
        return person;
    }



















}

