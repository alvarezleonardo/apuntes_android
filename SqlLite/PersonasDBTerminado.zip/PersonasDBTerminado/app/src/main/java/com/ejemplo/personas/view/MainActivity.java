package com.ejemplo.personas.view;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import com.ejemplo.personas.R;
import com.ejemplo.personas.controller.PersonController;
import com.ejemplo.personas.model.Person;

import java.util.List;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void addPerson(View view){

        PersonController personController = new PersonController();

        //Creo una persona
        Person andres = new Person();
        andres.setId(1);
        andres.setName("Andres");
        andres.setLastName("Furlan");
        andres.setAge(26);
        andres.setLastTweet("Hello World");


        personController.addPerson(this, andres);

        //Creo una persona
        Person mariano = new Person();
        mariano.setId(2);
        mariano.setName("Mariano");
        mariano.setLastName("D'Agostino");
        mariano.setAge(26);
        mariano.setLastTweet("Hello World");

        //Agrego a la persona
        personController.addPerson(this,mariano);




    }

    public void getPerson(View view) {
        //Obtengo la persona con id 1 de mi DB
        PersonController personController = new PersonController();

        Person person = personController.getPerson(this,2);
        Toast.makeText(this, person.toString(), Toast.LENGTH_SHORT).show();

    }

    public void getAllPerson(View view) {
        //Obtengo la lista de personas
        PersonController personController = new PersonController();
        List<Person> personList = personController.getAllPerson(this);

        Toast.makeText(this, personList.toString(), Toast.LENGTH_SHORT).show();

    }

}
