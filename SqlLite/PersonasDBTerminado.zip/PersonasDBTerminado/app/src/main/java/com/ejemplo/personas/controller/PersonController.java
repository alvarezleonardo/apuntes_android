package com.ejemplo.personas.controller;

import android.content.Context;

import com.ejemplo.personas.dao.PersonDAO;
import com.ejemplo.personas.model.Person;

import java.util.List;

/**
 * Created by digitalhouse on 6/06/16.
 */
public class PersonController {

    public void addPerson(Context context, Person unaPersona){
        //Obtener un DAO
        PersonDAO personDAO = new PersonDAO(context);
        //Agregar persona
        personDAO.addPersonToDatabase(unaPersona);
    }

    public Person getPerson(Context context,Integer id){
        //Obtener un DAO
        PersonDAO personDAO = new PersonDAO(context);

        //Pedirle al dao la persona de esa posicion
        Person person = personDAO.getPersonFromDB(id);

        return person;
    }

    public List<Person> getAllPerson(Context context){
        //Obtener un DAO
        PersonDAO personDAO = new PersonDAO(context);

        //Pedirle al dao todas las personas
        return personDAO.getPersonsFromDatabase();
    }
}
