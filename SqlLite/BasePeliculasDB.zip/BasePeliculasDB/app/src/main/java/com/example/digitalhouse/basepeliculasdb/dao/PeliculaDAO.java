package com.example.digitalhouse.basepeliculasdb.dao;

/**
 * Created by digitalhouse on 31/10/16.
 */
public class PeliculaDAO {
}
