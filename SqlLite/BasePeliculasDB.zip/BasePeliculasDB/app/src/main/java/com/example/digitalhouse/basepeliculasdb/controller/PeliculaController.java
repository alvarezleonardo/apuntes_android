package com.example.digitalhouse.basepeliculasdb.controller;

/**
 * Created by digitalhouse on 31/10/16.
 */
public class PeliculaController {
}
