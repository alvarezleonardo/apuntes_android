package com.example.digitalhouse.miprimerappbar;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Toolbar miToolbar = (Toolbar) findViewById(R.id.toolbar);
        miToolbar.setTitle("Actividad 1");
        setSupportActionBar(miToolbar);

    }

    //LE DIGO AL TOOLBAR QUE AGREGUE ESTAS OPCIONES
    @Override
    public boolean onCreateOptionsMenu(Menu menu){
        getMenuInflater().inflate(R.menu.menu_toolbar, menu);
        return true;
    }

    //METODO PARA DARLE COMPORTAMIENTO A CADA BOTON DEL ACTION BAR
    @Override
    public boolean onOptionsItemSelected(MenuItem item){
        switch (item.getItemId()){
            case R.id.search_action1:
                Toast.makeText(this,"Buscando 1",Toast.LENGTH_SHORT).show();
                return true;

            case R.id.search_action2:
                Toast.makeText(this,"Buscando 2",Toast.LENGTH_SHORT).show();
                return true;

            default:
                return super.onOptionsItemSelected(item);
        }
    }

    public void llamarOtraActividad(View view){
        Intent unIntent = new Intent(this,SecondActivity.class);
        startActivity(unIntent);
    }
}
