package com.example.digitalhouse.segundaclase;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }


    public void botonApretado(View view){
        TextView textViewNombre = (TextView) findViewById(R.id.textViewNombre);
        EditText unEditTextNombre = (EditText)findViewById(R.id.editTextNombre);

        if(unEditTextNombre.getText().toString().equals("")) {
            textViewNombre.setText("Por favor completa nombre");
        }
        else{
            Toast.makeText(MainActivity.this, "Asdasd", Toast.LENGTH_SHORT).show();  textViewNombre.setText("Por favor completa nombre");
        }
    }
















}
