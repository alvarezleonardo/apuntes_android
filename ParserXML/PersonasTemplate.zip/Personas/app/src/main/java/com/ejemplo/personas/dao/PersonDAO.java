package com.ejemplo.personas.dao;

import android.content.Context;
import android.content.res.AssetManager;
import android.util.Log;
import android.util.Xml;

import com.ejemplo.personas.model.Person;

import org.xmlpull.v1.XmlPullParser;

import java.io.InputStream;

/**
 * Created by digitalhouse on 6/06/16.
 */
public class PersonDAO {

    public Person getPerson(Context context){
        XmlPullParser parser = Xml.newPullParser();
        Person result = null;
        try{
            AssetManager manager = context.getAssets();
            InputStream input = manager.open("person.xml");
            // Vas a leer este archivo (input)
            parser.setInput(input, null);
            Integer status = parser.getEventType();
            while (status != XmlPullParser.END_DOCUMENT){
                switch (status){
                    case XmlPullParser.START_DOCUMENT:
                        result = new Person();
                        break;
                    case XmlPullParser.START_TAG:
                        // PROGRAMAR ACA.

                        break;
                }
                status = parser.next();
            }
        }catch (Exception e){
            e.printStackTrace();
        }

        Log.d("INFO", result.toString());

        return result;
    }


}
