package com.example.digitalhouse.noticias.utils;

public interface ResultListener<T> {

    void finish(T resultado);
}