package primeraapp.digitalhouse.weatherxml.model;

/**
 * Created by digitalhouse on 24/10/16.
 */
public class Clouds {

    private Integer all;

    public Integer getAll() {
        return all;
    }

    public void setAll(Integer all) {
        this.all = all;
    }
}
