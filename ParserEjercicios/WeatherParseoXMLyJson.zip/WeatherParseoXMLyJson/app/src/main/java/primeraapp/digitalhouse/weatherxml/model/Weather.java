package primeraapp.digitalhouse.weatherxml.model;

/**
 * Created by digitalhouse on 24/10/16.
 */
public class Weather {

    private Integer temperature;
    private Integer humidity;
    private Integer pressure;
    private Integer temperature_min;
    private Integer temperature_max;

    public Integer getTemperature() {
        return temperature;
    }

    public void setTemperature(Integer temperature) {
        this.temperature = temperature;
    }

    public Integer getHumidity() {
        return humidity;
    }

    public void setHumidity(Integer humidity) {
        this.humidity = humidity;
    }

    public Integer getPressure() {
        return pressure;
    }

    public void setPressure(Integer pressure) {
        this.pressure = pressure;
    }

    public Integer getTemperature_min() {
        return temperature_min;
    }

    public void setTemperature_min(Integer temperature_min) {
        this.temperature_min = temperature_min;
    }

    public Integer getTemperature_max() {
        return temperature_max;
    }

    public void setTemperature_max(Integer temperature_max) {
        this.temperature_max = temperature_max;
    }
}
