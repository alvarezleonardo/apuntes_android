package primeraapp.digitalhouse.weatherxml.controller;

import android.content.Context;

import primeraapp.digitalhouse.weatherxml.dao.WeatherDAO;
import primeraapp.digitalhouse.weatherxml.model.WeatherInfoContainer;

/**
 * Created by digitalhouse on 24/10/16.
 */
public class WeatherController {

    public WeatherInfoContainer getWeatherInfoXML(Context context){
        WeatherDAO weatherDAO = new WeatherDAO();
        WeatherInfoContainer weatherInfoContainer = weatherDAO.getWeatherInfoXML(context);
        return weatherInfoContainer;
    }

    public WeatherInfoContainer getWeatherInfoJson(Context context){
        WeatherDAO weatherDAO = new WeatherDAO();
        WeatherInfoContainer weatherInfoContainer = weatherDAO.getWeatherInfoJSON(context);
        return weatherInfoContainer;
    }

}
