package primeraapp.digitalhouse.weatherxml.dao;

import android.content.Context;
import android.content.res.AssetManager;
import android.util.Log;
import android.util.Xml;

import com.google.gson.Gson;

import org.xmlpull.v1.XmlPullParser;

import java.io.BufferedReader;
import java.io.Externalizable;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

import primeraapp.digitalhouse.weatherxml.model.Clouds;
import primeraapp.digitalhouse.weatherxml.model.Coordinates;
import primeraapp.digitalhouse.weatherxml.model.Location;
import primeraapp.digitalhouse.weatherxml.model.Rain;
import primeraapp.digitalhouse.weatherxml.model.Weather;
import primeraapp.digitalhouse.weatherxml.model.WeatherInfoContainer;
import primeraapp.digitalhouse.weatherxml.model.Wind;

/**
 * Created by digitalhouse on 24/10/16.
 */
public class WeatherDAO {

    //PARSEO EN JSON
    public WeatherInfoContainer getWeatherInfoJSON(Context context){

        WeatherInfoContainer result = null;

        try {
            // ABRIR ARCHIVO
            AssetManager manager = context.getAssets();
            InputStream inputStream = manager.open("weather.json");
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream));

            // USO GSON
            Gson gson = new Gson();
            result = gson.fromJson(bufferedReader, WeatherInfoContainer.class);
        }
        catch (Exception e){
            e.printStackTrace();
        }
        Log.d("tag", result.toString());
        return result;
    }

    //PARSEO EN XML
    public WeatherInfoContainer getWeatherInfoXML(Context context){
        XmlPullParser parser = Xml.newPullParser();
        WeatherInfoContainer result = null;
        Coordinates coordinates = null;
        Location location = null;
        List<Weather> weatherList = null;
        Weather weatherAAgregar = null;
        Wind wind = null;
        Rain rain = null;
        Clouds clouds = null;
        try {
            AssetManager manager = context.getAssets();
            InputStream input = manager.open("weather.xml");

            parser.setInput(input, null);
            Integer status = parser.getEventType();
            while(status != XmlPullParser.END_DOCUMENT) {
                switch (status) {
                    case XmlPullParser.START_DOCUMENT:
                        result = new WeatherInfoContainer();
                        weatherList = new ArrayList<>();
                        break;
                    case XmlPullParser.START_TAG:
                        if (parser.getName().equals("coordinates")){
                            coordinates = new Coordinates();
                        }
                        if (parser.getName().equals("longitude")){
                            coordinates.setLongitude(Integer.parseInt(parser.nextText()));
                        }
                        if (parser.getName().equals("latitude")){
                            coordinates.setLatitude(Integer.parseInt(parser.nextText()));
                        }
                        if (parser.getName().equals("location")){
                            location = new Location();
                        }
                        if (parser.getName().equals("country")){
                            location.setCountry(parser.nextText());
                        }
                        if (parser.getName().equals("city")){
                            location.setCity(parser.nextText());
                        }
                        if (parser.getName().equals("sunrise")){
                            location.setSunrise(Integer.parseInt(parser.nextText()));
                        }
                        if (parser.getName().equals("sunset")){
                            location.setSunset(Integer.parseInt(parser.nextText()));
                        }
                        if (parser.getName().equals("weather")){
                            weatherAAgregar = new Weather();
                        }
                        if (parser.getName().equals("temperature")){
                            weatherAAgregar.setTemperature(Integer.parseInt(parser.nextText()));
                        }
                        if (parser.getName().equals("humidity")){
                            weatherAAgregar.setHumidity(Integer.parseInt(parser.nextText()));
                        }
                        if (parser.getName().equals("pressure")){
                            weatherAAgregar.setPressure(Integer.parseInt(parser.nextText()));
                        }
                        if (parser.getName().equals("temperature_min")){
                            weatherAAgregar.setTemperature_min(Integer.parseInt(parser.nextText()));
                        }
                        if (parser.getName().equals("temperature_max")){
                            weatherAAgregar.setTemperature_max(Integer.parseInt(parser.nextText()));
                        }
                        if (parser.getName().equals("wind")){
                            wind = new Wind();
                        }
                        if (parser.getName().equals("speed")){
                            wind.setSpeed(Double.parseDouble(parser.nextText()));
                        }
                        if (parser.getName().equals("deg")){
                            wind.setDeg(Double.parseDouble(parser.nextText()));
                        }
                        if (parser.getName().equals("rain")){
                            rain = new Rain();
                        }
                        if (parser.getName().equals("probability")){
                            rain.setProbability(Integer.parseInt(parser.nextText()));
                        }
                        if (parser.getName().equals("clouds")){
                            clouds = new Clouds();
                        }
                        if (parser.getName().equals("all")){
                            clouds.setAll(Integer.parseInt(parser.nextText()));
                        }
                        break;
                    case XmlPullParser.END_TAG:
                        if (parser.getName().equals("weather")){
                            weatherList.add(weatherAAgregar);
                        }
                        if (parser.getName().equals("weatherInformation")){
                            result.setCoordinates(coordinates);
                            result.setLocation(location);
                            result.setWeatherList(weatherList);
                            result.setWind(wind);
                            result.setRain(rain);
                            result.setClouds(clouds);
                        }
                        break;
                }
                status = parser.next();
            }
        }
        catch (Exception e){
            e.printStackTrace();
        }
        Log.d("tag", result.toString());
        return result;
    }

}
