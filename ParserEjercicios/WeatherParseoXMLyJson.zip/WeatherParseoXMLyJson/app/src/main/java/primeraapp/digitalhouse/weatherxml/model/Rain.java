package primeraapp.digitalhouse.weatherxml.model;

/**
 * Created by digitalhouse on 24/10/16.
 */
public class Rain {

    private Integer probability;

    public Integer getProbability() {
        return probability;
    }

    public void setProbability(Integer probability) {
        this.probability = probability;
    }
}
