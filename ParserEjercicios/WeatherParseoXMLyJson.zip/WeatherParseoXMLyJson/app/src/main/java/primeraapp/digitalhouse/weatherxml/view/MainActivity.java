package primeraapp.digitalhouse.weatherxml.view;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

import primeraapp.digitalhouse.weatherxml.R;
import primeraapp.digitalhouse.weatherxml.controller.WeatherController;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void cargarInfoClimaXml (View view){
        WeatherController controller = new WeatherController();
        controller.getWeatherInfoXML(this);
    }

    public void cargarInfoClimaJson (View view){
        WeatherController controller = new WeatherController();
        controller.getWeatherInfoJson(this);
    }

}
