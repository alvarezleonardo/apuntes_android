package com.example.lab.animaciones;

import android.animation.Animator;
import android.animation.AnimatorInflater;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class XMLAnimations extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_xmlanimations);
    }

    public void animarBoton(View view){
        Animator animator = AnimatorInflater.loadAnimator(this, R.animator.fade_out);
        animator.setTarget(view);
        animator.setDuration(1000);
        animator.start();
    }

    public void animarOtroBoton(View view){
        Animator animator = AnimatorInflater.loadAnimator(this, R.animator.rotate_and_translatey);
        animator.setTarget(view);
        animator.start();
    }

    public void proximoActivity(View view){
        Intent intent = new Intent(this, FragmentTransitionActivity.class);
        startActivity(intent);
        overridePendingTransition(R.anim.fade_in, R.anim.fade_out);
    }
}
