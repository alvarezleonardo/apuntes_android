package com.example.lab.animaciones;

import android.content.Intent;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class FragmentTransitionActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fragment_transition);
    }

    public void cambiarDeFragment(View view){

        SimpleFragment simpleFragment = new SimpleFragment();
        FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();

        fragmentTransaction.setCustomAnimations(R.anim.fade_in, R.anim.fade_out);


        fragmentTransaction.replace(R.id.fragmentHolder, simpleFragment);
        fragmentTransaction.commit();

    }

}
