package com.example.lab.animaciones;

import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class CombinedAnimations extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_combined_animations);
    }

    public void animarBoton(View view){
        ObjectAnimator animacion1 = ObjectAnimator.ofFloat(view, "rotation", 720).setDuration(2000);
        ObjectAnimator animacion2 = ObjectAnimator.ofFloat(view, "translationY", 500).setDuration(2000);
        AnimatorSet set = new AnimatorSet();
        set.playTogether(animacion1, animacion2);
        set.start();
    }

    public void animarOtroBoton(View view){

        ObjectAnimator animacion1 = ObjectAnimator.ofFloat(view, "rotation", 720).setDuration(2000);
        ObjectAnimator animacion2 = ObjectAnimator.ofFloat(view, "translationY", 600).setDuration(2000);
        AnimatorSet set = new AnimatorSet();
        set.playTogether(animacion1, animacion2);

        ObjectAnimator animacion3 = ObjectAnimator.ofFloat(view, "scaleX", 1.7f).setDuration(2000);
        ObjectAnimator animacion4 = ObjectAnimator.ofFloat(view, "scaleY", 1.7f).setDuration(2000);
        ObjectAnimator animacion5 = ObjectAnimator.ofFloat(view, "translationX", 250).setDuration(2000);
        AnimatorSet set2 = new AnimatorSet();
        set.playTogether(animacion3, animacion4, animacion5);

        AnimatorSet setCombinado = new AnimatorSet();
        setCombinado.playTogether(set, set2);
        setCombinado.start();

    }

    public void irAOtraActivity(View view){
        Intent intent = new Intent(this, XMLAnimations.class);
        startActivity(intent);
        overridePendingTransition(R.anim.fade_in, R.anim.fade_out);
    }

}

