package com.example.lab.animaciones;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ObjectAnimator;
import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    ObjectAnimator animationAlpha;
    ObjectAnimator animationRotation;
    ObjectAnimator animationScaleX;
    ObjectAnimator animationScaleY;
    ObjectAnimator animationTranslationX;
    ObjectAnimator animationTranslationY;
    ObjectAnimator animationX;
    ObjectAnimator animationY;

    Button buttonAlpha;
    Button buttonRotation;
    Button buttonScaleX;
    Button buttonScaleY;
    Button buttonTranslationX;
    Button buttonTranslationY;
    Button buttonX;
    Button buttonY;

    AnimatorListenerAdapter animatorListenerAdapter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        buttonAlpha = (Button) findViewById(R.id.buttonAlpha);
        buttonRotation = (Button) findViewById(R.id.buttonRotation);
        buttonScaleX = (Button) findViewById(R.id.buttonScaleX);
        buttonScaleY = (Button) findViewById(R.id.buttonScaleY);
        buttonTranslationX = (Button) findViewById(R.id.buttonTranslationX);
        buttonTranslationY = (Button) findViewById(R.id.buttonTranslationY);
        buttonX = (Button) findViewById(R.id.buttonX);
        buttonY = (Button) findViewById(R.id.buttonY);

        animationAlpha = ObjectAnimator.ofFloat(buttonAlpha, "alpha", 0f);
        animationRotation = ObjectAnimator.ofFloat(buttonRotation, "rotation", 360);
        animationScaleX = ObjectAnimator.ofFloat(buttonScaleX, "scaleX", 0.25f);
        animationScaleY = ObjectAnimator.ofFloat(buttonScaleY, "scaleY", 0.25f);
        animationTranslationX = ObjectAnimator.ofFloat(buttonTranslationX, "translationX", 100);
        animationTranslationY = ObjectAnimator.ofFloat(buttonTranslationY, "translationY", 50);
        animationX = ObjectAnimator.ofFloat(buttonX, "x", 200);
        animationY = ObjectAnimator.ofFloat(buttonY, "y", 150);

        animatorListenerAdapter = new AnimatorListenerAdapter() {
            @Override
            public void onAnimationEnd(Animator animation) {
                super.onAnimationEnd(animation);
                Toast.makeText(MainActivity.this, "Terminó la animación", Toast.LENGTH_SHORT).show();
            }
        };
    }

    public void animate(ObjectAnimator animation){

        animation.addListener(animatorListenerAdapter);
        animation.setDuration(1000);
        animation.start();
    }

    public void animationAlpha(View view){

        animate(animationAlpha);
    }
    public void animationRotation(View view){

        animate(animationRotation);
    }

    public void animationScaleX(View view){

        animate(animationScaleX);
    }
    public void animationScaleY(View view){

        animate(animationScaleY);
    }
    public void animationTranslationX(View view){

        animate(animationTranslationX);
    }
    public void animationTranslationY(View view){

        animate(animationTranslationY);
    }
    public void animationX(View view){

        animate(animationX);
    }
    public void animationY(View view){


        animate(animationY);
    }

    public void irAOtraActivity(View view){
        Intent intent = new Intent(this, CombinedAnimations.class);
        startActivity(intent);
        overridePendingTransition(R.anim.fade_in, R.anim.fade_out);
    }

}
