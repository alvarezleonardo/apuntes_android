package com.example.andres.solucionintegracionfragmentylistview;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * Created by andres on 04/10/16.
 */
public class AdapterProductos extends BaseAdapter {

    //Atributos necesarios del Adapter
    private Context miContext;
    private ArrayList<Producto> listaDeProductos;

    //Constructor, que recibe el contexto y la lista de productos que va a mostrar
    public AdapterProductos(Context miContext, ArrayList<Producto> listaDeProductos) {
        this.miContext = miContext;
        this.listaDeProductos = listaDeProductos;
    }

    @Override
    public int getCount() {
        return listaDeProductos.size();
    }

    @Override
    public Producto getItem(int i) {
        return listaDeProductos.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {

        //Busco un inflater
        LayoutInflater inflater = (LayoutInflater) miContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        //Igualo la view al resultado de inflar el layout detalle
        view = inflater.inflate(R.layout.list_view_detalle_producto, viewGroup, false);

        //me guardo la referencia del producto que estoy inflando, para facilitar el uso de sus atributos
        Producto producto = getItem(i);

        //Busco los componentes que voy a cambiar con la informacion de cada Producto y los cambio
        TextView textViewNombre = (TextView) view.findViewById(R.id.nombreProducto);
        TextView textViewDescripcion = (TextView) view.findViewById(R.id.descripcionProducto);
        TextView textViewPrecio = (TextView) view.findViewById(R.id.precioProducto);
        ImageView imageView = (ImageView) view.findViewById(R.id.imagenProducto);

        //Cambio el contenido de todos los componentes, segun cada producto
        textViewNombre.setText(producto.getNombre());
        textViewDescripcion.setText(producto.getDescripcion());
        textViewPrecio.setText("$ " + producto.getPrecio());
        imageView.setImageResource(producto.getImagen());

        //devuelvo la lista de cada celda del list view, modificada para cada producto
        return view;
    }
}
