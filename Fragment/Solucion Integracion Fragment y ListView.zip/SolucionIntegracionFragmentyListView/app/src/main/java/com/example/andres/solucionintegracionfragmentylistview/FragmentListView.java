package com.example.andres.solucionintegracionfragmentylistview;

import android.app.Fragment;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;

/**
 * Created by andres on 03/10/16.
 */
public class FragmentListView extends Fragment {

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        //Al crear la vista del fragment, inflo el xml que tiene el componente ListView
        View viewADevolver = inflater.inflate(R.layout.fragment_list_view, container, false);

        //Lo busco con el findViewById() y me lo guardo
        ListView miListViewProductos = (ListView) viewADevolver.findViewById(R.id.listViewProductos);

        //Creo un adaptador de productos, como veniamos haciendo, solo que el contexto que le paso lo saco del metodo
        // getActivity(), y este metodo devolvera la activity en el cual el fragment este pegado en ese momento
        AdapterProductos miAdaptadorProductos = new AdapterProductos(getActivity(), Producto.dameProductos());

        //le seteo el adapter que cree a la lista
        miListViewProductos.setAdapter(miAdaptadorProductos);

        //devuelvo la view que infle, con el listview y su adapter ya seteado
        return viewADevolver;
    }

}
