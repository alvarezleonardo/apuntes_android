package com.example.andres.solucionintegracionfragmentylistview;

import java.util.ArrayList;

/**
 * Created by andres on 03/10/16.
 */
public class Producto {

    //Atributos
    private String nombre;
    private String descripcion;
    private Integer precio;
    private Integer imagen;

    //Constructor
    public Producto(String nombre, String descripcion, Integer precio, Integer imagen) {
        this.nombre = nombre;
        this.descripcion = descripcion;
        this.precio = precio;
        this.imagen = imagen;
    }

    //Metodo estatico en donde esta hardcodeada la lista de productos
    public static ArrayList<Producto> dameProductos (){
        ArrayList<Producto> listaADevolver = new ArrayList<>();
        listaADevolver.add(new Producto("Samsung Re Piola para Muchachos", "Simplemente es un gran telefono " +
                "que todos deberian usar, muerte a iOS!!", 90000, R.drawable.samsung_galaxy_s7));
        listaADevolver.add(new Producto("Esta cosa", "Alguna otra cosa muy canchera y " +
                "que no sale tanta plata", 80, R.drawable.samsung_galaxy_s7));
        listaADevolver.add(new Producto("Esta otra cosa", "Alguna otra cosa muy canchera y " +
                "que no sale tanta plata", 87, R.drawable.samsung_galaxy_s7));
        listaADevolver.add(new Producto("Esta super cosa", "Alguna otra cosa muy canchera y " +
                "que no sale tanta plata", 130, R.drawable.samsung_galaxy_s7));
        listaADevolver.add(new Producto("Esta cosa 2", "Alguna otra cosa 2 muy canchera y " +
                "que no sale tanta plata", 8000, R.drawable.samsung_galaxy_s7));
        listaADevolver.add(new Producto("Esta cosa 2", "Alguna otra cosa 2 muy canchera y " +
                "que no sale tanta plata", 8000, R.drawable.samsung_galaxy_s7));
        listaADevolver.add(new Producto("Esta cosa 2", "Alguna otra cosa 2 muy canchera y " +
                "que no sale tanta plata", 8000, R.drawable.samsung_galaxy_s7));
        listaADevolver.add(new Producto("Esta cosa 2", "Alguna otra cosa 2 muy canchera y " +
                "que no sale tanta plata", 8000, R.drawable.samsung_galaxy_s7));
        listaADevolver.add(new Producto("Esta cosa 2", "Alguna otra cosa 2 muy canchera y " +
                "que no sale tanta plata", 8000, R.drawable.samsung_galaxy_s7));
        listaADevolver.add(new Producto("Esta cosa 2", "Alguna otra cosa 2 muy canchera y " +
                "que no sale tanta plata", 8000, R.drawable.samsung_galaxy_s7));

        return listaADevolver;
    }

    //GETTERS Y SETTERS
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public Integer getPrecio() {
        return precio;
    }

    public void setPrecio(Integer precio) {
        this.precio = precio;
    }

    public Integer getImagen() {
        return imagen;
    }

    public void setImagen(Integer imagen) {
        this.imagen = imagen;
    }
}
