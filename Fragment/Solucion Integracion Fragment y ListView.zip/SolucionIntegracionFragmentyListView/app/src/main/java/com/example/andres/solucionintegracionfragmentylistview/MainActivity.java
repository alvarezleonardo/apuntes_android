package com.example.andres.solucionintegracionfragmentylistview;

import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    private FragmentManager miFragmentManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Al crearse la Activity conseguimos el FragmentManager e iniciamos la Transaction
        miFragmentManager = getFragmentManager();
        FragmentTransaction unaTransaction = miFragmentManager.beginTransaction();

        //Creo una instancia del Fragment que voy a mostrar en la activity
        FragmentListView unFragmentListView = new FragmentListView();

        //Lo reemplazo en el contenedor de fragments, que es el Layout vacio que defini en el xml de la activity
        unaTransaction.replace(R.id.contenedorDeFragments, unFragmentListView);
        unaTransaction.commit();

    }

}
