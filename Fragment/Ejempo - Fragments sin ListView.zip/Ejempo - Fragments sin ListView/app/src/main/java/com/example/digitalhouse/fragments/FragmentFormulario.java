package com.example.digitalhouse.fragments;
import android.app.Fragment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

/**
 * Created by digitalhouse on 29/09/16.
 */
public class FragmentFormulario extends Fragment {

    @Override
    //LA FUNCION SE EJECUTA CUANDO CREO EL FRAGMENT
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        //LE DIGO AL FRAGMENT QUE UTILICE LA VISTA FRAGMENT FORMULARIO
        View view = inflater.inflate(R.layout.fragment_formulario, container, false);

        //CODIGO DE LO QUE VA A HACER EL FRAGMENT
        TextView unTextView = (TextView) view.findViewById(R.id.textViewFragment);

        unTextView.setText("Hello Fragments");

        return view;
    }











}
