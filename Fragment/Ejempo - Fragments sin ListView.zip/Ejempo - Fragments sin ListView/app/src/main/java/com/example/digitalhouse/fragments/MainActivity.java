package com.example.digitalhouse.fragments;


import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //PIDO UN FRAGMENT MANAGER
        FragmentManager fragmentManager = getFragmentManager();

        //PIDO UNA TRANSACCION
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();

        //CREO UNA INSTANCIA DEL FRAGMENT FORMULARIO
        FragmentFormulario fragmentFormulario = new FragmentFormulario();

        //LO CARGO EN EL ACTIVITY
        fragmentTransaction.replace(R.id.acaVaElFragment2, fragmentFormulario);

        //COMMIT - INDICA QUE TERMINE LA TRANSACCION
        fragmentTransaction.commit();


        //PIDO UNA TRANSACCION
        fragmentTransaction = fragmentManager.beginTransaction();

        //CREO UNA INSTANCIA DEL FRAGMENT FORMULARIO
        FragmentFormulario fragmentFormulario2 = new FragmentFormulario();

        //LO CARGO EN EL ACTIVITY
        fragmentTransaction.replace(R.id.acaVaElFragment1, fragmentFormulario2);

        //COMMIT - INDICA QUE TERMINE LA TRANSACCION
        fragmentTransaction.commit();
    }













}
