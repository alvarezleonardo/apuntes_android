package com.ejemplo.post.view;

import android.content.Context;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;

import com.ejemplo.post.R;
import com.ejemplo.post.controller.PostController;
import com.ejemplo.post.model.Post;

import java.util.List;

import util.ResultListener;

public class MainActivity extends AppCompatActivity {
    //Declaro todas estas variables como globales ya que las voy a usar a lo largo de la clase.
    private RecyclerView recyclerView;
    private AdapterPost adapterPost;
    private SwipeRefreshLayout pullToRefresh;
    private PostController postController;
    private LinearLayoutManager linearLayoutManager;

    //Esta variable es una manera muy conveniente de guardarse siempre un contexto. Aca como estamos en un activity, el mismo va a ser el contexto.
    private Context context;

    //En esta variable voy a guardar el valor que representa la posicion del de la ultima fila visible
    private Integer lastVisibleItem;

    //En esta variable voy a guardar cuantas filas tiene la lista
    private Integer totalItemCount;

    //En esta variable voy a guardar si estamos haciendo el request y estamos esperando a que termine
    private Boolean isLoading = false;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Seteo el contexto y obtengo el recyclerView y el SwipeRefreshLayout
        context = this;
        recyclerView = (RecyclerView) findViewById(R.id.recyclerView);
        pullToRefresh = (SwipeRefreshLayout) findViewById(R.id.pullToRefresh);

        //Seteo el adapter y los elementos del recyclerView
        adapterPost = new AdapterPost(getApplicationContext());
        recyclerView.setAdapter(adapterPost);
        linearLayoutManager = new LinearLayoutManager(getApplicationContext(), LinearLayoutManager.VERTICAL, false);
        recyclerView.setLayoutManager(linearLayoutManager);

        //Aca seteo el listener de cuando escroleo el recyclerView
        recyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrolled(RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);

                //Aca me fijo si el controller termino de pedir todas las paginas
                //Si es asi salgo
                if (postController.isRequestPaginationEnded()){
                    return;
                }

                //Aca le pido la cantidad de items(filas) que hay en la lista
                totalItemCount = linearLayoutManager.getItemCount();

                //Aca pido el ultimo item(fila) visible que hay en la lista
                lastVisibleItem = linearLayoutManager.findLastVisibleItemPosition();

                //Si no esta pidiendo mas informacion y debo cargar mas hago el pedido

                if (!isLoading && totalItemCount <= lastVisibleItem + 1) {

                    adapterPost.addLoading();

                    postController.getPostListPaginated(new ResultListener<List<Post>>() {
                        @Override
                        public void finish(List<Post> resultado) {
                            adapterPost.removeLoading();

                            //Agrego aca los productos a la lista
                            adapterPost.addProductList(resultado);

                            //Aviso al adapter que la lista de produtos cambio
                            adapterPost.notifyDataSetChanged();

                            //Aca seteo a la variable que ya no estoy cargando mas informacion
                            isLoading = false;
                        }
                    }, context);
                    isLoading = true;
                }
            }
        });

        //Este metodo va a pedirle al postcontroller que va a crear que busque los posts y tambien actualizar el adaptador del recyclerView
        update();

        //Aca seteo el listener del pullToRefres. Cuando hago el pull y comienza la animacion del componente es ahi cuando se llama el codigo
        //en el onRefresh(), que en este caso va a hacer el update
        pullToRefresh.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                update();
            }
        });

    }


    //Aca es donde hacemos el pedido de posts y actualizamos el recyclerView
    private void update() {
        //Aca seteamos en true el pullToRefresh para que muestre la animacion en el caso de que no se este mostrando
        // Asi la primera vez que arranca la aplicacion y hace un update, por mas que no se hizo el gesto del pull
        // Vamos a mostrar igualmente la animacion para darle al usuario un feedback de que estamos haciendo algo

        //Instancio el PostController que me va a devolver todos los posts
        //El new lo hago aca ya que cada vez que voy a hacer un update en realidad estoy
        //cargando la lista desde 0, por lo cual necesito un nuevo PostController (por el tema del paginado)
        postController = new PostController();

        pullToRefresh.setRefreshing(true);

        postController.getPostListPaginated(new ResultListener<List<Post>>() {
            @Override
            public void finish(List<Post> resultado) {
                //Aca cargo el resuldato en el adapter
                adapterPost.setPostList(resultado);

                //Aca le tengo que notificar al adapter que hubo un cambio en sus elementoss
                adapterPost.notifyDataSetChanged();

                //Aca SIEMPRE tengo que RECORDAR que tengo que llamar a este metodo que saca la animacion del pull to refresh
                //Si no lo saco va a seguir la animacion del componente indefinidamente
                pullToRefresh.setRefreshing(false);
            }
        }, context);
    }

}











