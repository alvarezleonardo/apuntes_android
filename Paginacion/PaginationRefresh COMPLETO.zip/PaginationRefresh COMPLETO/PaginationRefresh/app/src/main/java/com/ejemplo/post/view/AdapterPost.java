package com.ejemplo.post.view;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import com.ejemplo.post.R;
import com.ejemplo.post.model.Post;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by andres on 22/06/16.
 */
public class AdapterPost extends RecyclerView.Adapter{

    private final int VIEW_TYPE_ITEM = 0;
    private final int VIEW_TYPE_LOADING = 1;

    private List<Post> postList;
    private Context context;

    public AdapterPost(Context context) {

        this.context = context;
        this.postList = new ArrayList<>();
    }

    public void setPostList(List<Post> postList) {
        this.postList = postList;
    }

    public void addProductList(List<Post> productList) {
        this.postList.addAll(productList);
    }

    //Este nuevo metodo me permite decir segun una posicion que tipo de elemento retornar.
    //Cuando nosotros agregamos un elemento o lo removimos con el
    // addLoading() o removeLoading() y le dijimos que se actualice
    //Se va a llamar a este metodo, que va a preguntar por la posicion que agregamos o sacamos
    @Override
    public int getItemViewType(int position) {
        if(postList.get(position) == null){
            return VIEW_TYPE_LOADING;
        }
        else{
            return VIEW_TYPE_ITEM;
        }
    }

    public void addLoading() {
        //Agrego un elemento de tipo null a la lista, este me va a servir para luego cargar aca un loading
        postList.add(null);

        //Aviso al adapter que modifique la lista y donde
        this.notifyDataSetChanged();
    }

    public void removeLoading() {
        //Saco el loading de la lista
        postList.remove(postList.size() - 1);

        //Aviso al adapter que removi el loading
        this.notifyDataSetChanged();
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        //Aca dependiendo del tipo de viewType que me piden
        //Inflo o el detalle de un post o el loading circular
        if (viewType == VIEW_TYPE_ITEM) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.recycler_view_detalle, parent, false);
            return new PostViewHolder(view);
        } else if (viewType == VIEW_TYPE_LOADING) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.recycler_view_progress_bar, parent, false);
            return new LoadingViewHolder(view);
        }
        return null;
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
        //Aca dependiendo de que vierholder me llega bindeo a un producto
        //o seteo el loading circular
        if (holder instanceof PostViewHolder) {

            Post aProduct = postList.get(position);
            PostViewHolder unTitularViewHolder = (PostViewHolder) holder;
            unTitularViewHolder.bindProduct(aProduct, context);
        }
        else if (holder instanceof LoadingViewHolder) {

            LoadingViewHolder loadingViewHolder = (LoadingViewHolder) holder;
            loadingViewHolder.progressBar.setIndeterminate(true);
        }
    }

    @Override
    public int getItemCount() {
        return postList.size();
    }

    private static class PostViewHolder extends RecyclerView.ViewHolder{

        private TextView textViewId;
        private TextView textViewTitulo;
        private TextView textViewBody;
        private ImageView imageViewThumbnail;

        public PostViewHolder(View itemView) {
            super(itemView);
            textViewId = (TextView) itemView.findViewById(R.id.textViewId);
            textViewTitulo = (TextView) itemView.findViewById(R.id.textViewTitulo);
            textViewBody = (TextView) itemView.findViewById(R.id.textViewBody);
            imageViewThumbnail = (ImageView) itemView.findViewById(R.id.imageViewThumbnail);
        }

        public void bindProduct(Post aProduct, Context context){
            textViewId.setText(aProduct.getID());
            textViewTitulo.setText(aProduct.getTitle());
            textViewBody.setText(aProduct.getBody());
            Picasso.with(context).load("https://upload.wikimedia.org/wikipedia/commons/thumb/1/12/User_icon_2.svg/2000px-User_icon_2.svg.png").error(R.drawable.offlineuser).into(imageViewThumbnail);
        }
    }

    private class LoadingViewHolder extends RecyclerView.ViewHolder {
        public ProgressBar progressBar;

        public LoadingViewHolder(View itemView) {
            super(itemView);
            progressBar = (ProgressBar) itemView.findViewById(R.id.progressBarRecyclerView);
        }
    }
}
