package com.ejemplo.post.dao;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.AsyncTask;

import com.ejemplo.post.model.Post;
import com.ejemplo.post.model.PostContainer;
import com.google.gson.Gson;

import java.util.ArrayList;
import java.util.List;

import util.DAOException;
import util.HTTPConnectionManager;
import util.ResultListener;

/**
 * Created by digitalhouse on 6/06/16.
 */
public class PostDAO extends SQLiteOpenHelper {

    //CONSTANTES PARA LOS NOMBRES DE LA BD Y LOS CAMPOS
    private static final String DATABASENAME = "PostDB";
    private static final Integer DATABASEVERSION = 1;

    //TABLA PERSONA CON SUS CAMPOS
    private static final String TABLEPRODUCT = "Post";
    private static final String ID = "ID";
    private static final String TITLE = "title";
    private static final String BODY = "Body";

    //El contexto lo necesitamos para poder crear una BD.
    private Context context;

    //Constructor que permite crear la BD
    public PostDAO(Context context) {
        super(context, DATABASENAME, null, DATABASEVERSION);
        this.context = context;
    }

    //CREACION DE LA BASE DE DATOS POR PRIMERA VEZ
    @Override
    public void onCreate(SQLiteDatabase db) {

        //Creo la tabla que contendrá mi base de datos
        String createTable = "CREATE TABLE " + TABLEPRODUCT + "("
                + ID + " INTEGER PRIMARY KEY, "
                + TITLE + " TEXT, "
                + BODY + " TEXT " + ")";

        db.execSQL(createTable);
    }

    //SE EJECUTA CUANDO SE MODIFICA ALGO EN LA ESTRUCTURA DE LA TABLA
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
    }

    //METODO QUE ME PERMITE AGREGAR UNA LISTA DE POSTS A MI BASE DE DATOS
    public void addPosts(List<Post> postList) {
        for (Post aPost : postList) {
            if(!checkIfExist(aPost.getID())) {
                this.addProduct(aPost);
            }
        }
    }

    //METODO QUE ME PERMITE CHEQUEAR SI EXISTIA UN POST EN MI BASE DE DATOS
    private Boolean checkIfExist(String aPostID) {

        SQLiteDatabase database = getReadableDatabase();

        String selectQuery = "SELECT * FROM " + TABLEPRODUCT
                + " WHERE " + ID + "==" + aPostID;

        Cursor result = database.rawQuery(selectQuery, null);
        Integer count = result.getCount();

//        Log.v("PostDAO", "Post " + aPostID + " ya esta en la base");

        database.close();

        return (count > 0);
    }

    //METODO QUE ME PERMITE AGREGAR UN PRODUCTO A MI MI BD
    public void addProduct(Post post) {
        SQLiteDatabase database = getWritableDatabase();

        ContentValues row = new ContentValues();

        //Obtengo los datos y los cargo en el row
        row.put(ID, post.getID());
        row.put(TITLE, post.getTitle());
        row.put(BODY, post.getBody());

        database.insert(TABLEPRODUCT, null, row);

        database.close();
    }

    public List<Post> getAllPostsFromDatabase() {

        SQLiteDatabase database = getReadableDatabase();

        String selectQuery = "SELECT * FROM " + TABLEPRODUCT;
        Cursor cursor = database.rawQuery(selectQuery, null);

        List<Post> postList = new ArrayList<>();
        while(cursor.moveToNext()){

            //TOMO LOS DATOS DE CADA POST
            Post post = new Post();

            post.setID(cursor.getString(cursor.getColumnIndex(ID)));
            post.setTitle(cursor.getString(cursor.getColumnIndex(TITLE)));
            post.setBody(cursor.getString(cursor.getColumnIndex(BODY)));

            //AGREGO UN POST A LA LISTA
            postList.add(post);
        }

        return postList;
    }


    //ESTE METODO CHEQUEA SI TIENE CONEXION DE INTERNET, EN CASO AFIRMATIVO GENERAMOS EL ASYNC TASK Y PEDIMOS EL LISTADO A LA
    //URL, EN CASO NEGATIVO PEDIMOS EL CONTENIDO A LA BASE DE DATOS.
    public void getAllPosts(final ResultListener<List<Post>> listener) {

        RetrievePostTask retrieveProductsTask = new RetrievePostTask(listener);
        retrieveProductsTask.execute();
    }

    //ESTE METODO CHEQUEA SI TIENE CONEXION DE INTERNET, EN CASO AFIRMATIVO GENERAMOS EL ASYNC TASK Y PEDIMOS EL LISTADO A LA
    //URL, EN CASO NEGATIVO PEDIMOS EL CONTENIDO A LA BASE DE DATOS.
    public void getPostsPaginated(final ResultListener<List<Post>> listener,
                                  Integer offset, Integer limit) {
        RetrievePostPaginatedTask retrieveProductsTask =
                new RetrievePostPaginatedTask(listener,offset, limit);
        retrieveProductsTask.execute();
    }

    //ESTA CLASE ES UNA CLASE QUE ME PERMITE GENERAR UNA TAREA ASINCRONICA. ES DECIR, ESTA TAREA SE EJECUTARA
    // INDEPENDIENTEMENTE DE LO QUE ESTE HACIENDO COMO ACTIVIDAD PRINCIPAL
    class RetrievePostPaginatedTask extends AsyncTask<String, Void, List<Post>> {

        private ResultListener<List<Post>> listener;

        //Aca voy a guardar el offset y el limit que me van a pasar para hacer el pedido al servicio
        private Integer offset;

        private Integer limit;

        public RetrievePostPaginatedTask(ResultListener<List<Post>> listener,
                                         Integer offset, Integer limit) {
            this.listener = listener;
            this.offset = offset;
            this.limit = limit;
        }

        //Esto método se ejecuta mientras sigue corriendo la tarea principal. Aqui lo que haremos es conectarnos
        // al servicio y descargar la lista.
        @Override
        protected List<Post> doInBackground(String... params) {

            HTTPConnectionManager connectionManager = new HTTPConnectionManager();
            String input = null;

            try {
                //ACA LE CONCATENO AL PEDIDO EL OFFSET
                input = connectionManager.getRequestString("http://blooming-garden-41675.herokuapp.com/posts/paginated?offset="+offset+"&limit=" + limit);
            } catch (DAOException e) {
                e.printStackTrace();
            }

            Gson gson = new Gson();
            PostContainer postContainer = gson.fromJson(input, PostContainer.class);

            return postContainer.getResults();
        }

        //Una vez terminado el procesamiento, le avisamos al listener que ya tiene la lista disponible.
        @Override
        protected void onPostExecute(List<Post>posts) {

            addPosts(posts);
            this.listener.finish(posts);
        }
    }

    //ESTA CLASE ES UNA CLASE QUE ME PERMITE GENERAR UNA TAREA ASINCRONICA. ES DECIR, ESTA TAREA SE EJECUTARA
// INDEPENDIENTEMENTE DE LO QUE ESTE HACIENDO COMO ACTIVIDAD PRINCIPAL
    class RetrievePostTask extends AsyncTask<String, Void, List<Post>> {

        private ResultListener<List<Post>> listener;

        public RetrievePostTask(ResultListener<List<Post>> listener) {
            this.listener = listener;
        }

        //Esto método se ejecuta mientras sigue corriendo la tarea principal. Aqui lo que haremos es conectarnos
        // al servicio y descargar la lista.
        @Override
        protected List<Post> doInBackground(String... params) {
            try {
                Thread.sleep(5000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }


            HTTPConnectionManager connectionManager = new HTTPConnectionManager();
            String input = null;

            try {
                input = connectionManager.getRequestString("http://blooming-garden-41675.herokuapp.com/posts/paginated");
            } catch (DAOException e) {
                e.printStackTrace();
            }

            Gson gson = new Gson();
            PostContainer postContainer = gson.fromJson(input, PostContainer.class);

            return postContainer.getResults();
        }

        //Una vez terminado el procesamiento, le avisamos al listener que ya tiene la lista disponible.
        @Override
        protected void onPostExecute(List<Post> productList) {

            addPosts(productList);
            this.listener.finish(productList);
        }
    }



}




















