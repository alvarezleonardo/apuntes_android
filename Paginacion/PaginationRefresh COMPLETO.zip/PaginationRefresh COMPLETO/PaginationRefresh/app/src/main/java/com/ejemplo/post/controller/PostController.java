package com.ejemplo.post.controller;

import android.content.Context;

import com.ejemplo.post.dao.PostDAO;
import com.ejemplo.post.model.Post;

import java.util.List;

import util.HTTPConnectionManager;
import util.ResultListener;

/**
 * Created by digitalhouse on 6/06/16.
 */
public class PostController {
    //Aca me guardo cuando pido algo al DAO cuanto me viene
    //Como el DAO esta paginado, cuando me venga una cantidad menor de items esto me va a indicar
    //el fin del paginado, por lo cual ahi voy a setear el endPaging en true
    private Integer pageSize = 10;
    private Boolean endPaging = false;

    //Aca voy a guardar cuantos posts ya pedi, para pedirle al DAO que me de los posts a partir de este offset
    private Integer offset = 0;


    //Uso este metodo que usa la View para avisar si no hay mas posts que pedir
    public Boolean isRequestPaginationEnded(){
        return endPaging;
    }

    //El controller se encarga de pedirle la lista al DAO y luego le avisa al listener de la vista que ya esta disponible para que la use.
    public void getPostListPaginated(final ResultListener<List<Post>> listenerFromView, Context context) {

        PostDAO postDAO = new PostDAO(context);
        if (HTTPConnectionManager.isNetworkingOnline(context)) {

            //SI ESTOY ONLINE PIDO AL DAO QUE ME TRAIGA LAS COSAS DESDE EL SERVICIO
            postDAO.getPostsPaginated(new ResultListener<List<Post>>() {
                @Override
                public void finish(List<Post> resultado) {

                    //Aca me fijo si la cantidad que me vino del DAO es menor a la ultima
                    //Si es asi quiere decir que el paginado termino y no hay
                    //mas informacion para pedir
                    if (resultado.size() < pageSize) {
                        endPaging = true;
                    }

                    //Aca es donde le sumo al offset la cantidad de posts que me vino del ultimo pedido
                    offset = offset + pageSize;

                    listenerFromView.finish(resultado);
                }
            },offset,pageSize);
        } else {
            //CASO OFFLINE: Solicito al DAO la lista de POST que esta almacenada en la base de datos
            List<Post> postList = postDAO.getAllPostsFromDatabase();

            //Le aviso al listener de la vista que ya tengo la lista.
            listenerFromView.finish(postList);
        }
    }


    //El controller se encarga de pedirle la lista al DAO y luego le avisa al listener de la vista que ya esta disponible para que la use.
    public void getProductList(final ResultListener<List<Post>> listenerFromView, Context context) {

        PostDAO postDAO = new PostDAO(context);
        if (HTTPConnectionManager.isNetworkingOnline(context)) {

            //SI ESTOY ONLINE PIDO AL DAO QUE ME TRAIGA LAS COSAS DESDE EL SERVICIO
            postDAO.getAllPosts(new ResultListener<List<Post>>() {
                @Override
                public void finish(List<Post> resultado) {
                    listenerFromView.finish(resultado);
                }
            });
        } else {
            //CASO OFFLINE: Solicito al DAO la lista de POST que esta almacenada en la base de datos
            List<Post> postList = postDAO.getAllPostsFromDatabase();

            //Le aviso al listener de la vista que ya tengo la lista.
            listenerFromView.finish(postList);
        }
    }

}
