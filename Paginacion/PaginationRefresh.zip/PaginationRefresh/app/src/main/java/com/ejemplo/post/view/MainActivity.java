package com.ejemplo.post.view;

import android.content.Context;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;

import com.ejemplo.post.R;
import com.ejemplo.post.controller.PostController;
import com.ejemplo.post.model.Post;

import java.util.List;

import util.ResultListener;

public class MainActivity extends AppCompatActivity {
    //Declaro todas estas variables como globales ya que las voy a usar a lo largo de la clase.
    private RecyclerView recyclerView;
    private AdapterPost adapterPost;
    private PostController postController;
    private LinearLayoutManager linearLayoutManager;
    private Boolean isLoading = false;



    //Esta variable es una manera muy conveniente de guardarse siempre un contexto. Aca como estamos en un activity, el mismo va a ser el contexto.
    private Context context;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Seteo el contexto y obtengo el recyclerView y el SwipeRefreshLayout
        context = this;
        recyclerView = (RecyclerView) findViewById(R.id.recyclerView);


        //Seteo el adapter y los elementos del recyclerView
        adapterPost = new AdapterPost(getApplicationContext());
        recyclerView.setAdapter(adapterPost);
        linearLayoutManager = new LinearLayoutManager(getApplicationContext(), LinearLayoutManager.VERTICAL, false);
        recyclerView.setLayoutManager(linearLayoutManager);

        //CARGAR LA LISTA - EN FORMA PAGINADA
        postController = new PostController();
        if(!postController.getEndPaging()){
            isLoading = true;
            postController.getPostListPaginated(new ResultListener<List<Post>>() {
                @Override
                public void finish(List<Post> resultado) {
                    adapterPost.addPostList(resultado);
                    adapterPost.notifyDataSetChanged();
                    isLoading = false;
                }
            });

        }


        //LE AGREGO UN LISTENER AL RECYCLER VIEW PARA RECONOCER EL SCROLL
        recyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrolled(RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);

                //PIDO LA CANTIDAD TOTAL DE ITEMS
                Integer totalItemCount = linearLayoutManager.getItemCount();


                //PIDO EL ULTIMO ITEM VISIBLE EN PANTALLA
                Integer lastVisibleItem = linearLayoutManager.findLastVisibleItemPosition();


                if(!isLoading && lastVisibleItem + 1 >= totalItemCount) {

                    //PIDO UNA PAGINA MAS
                    isLoading = true;
                    if (!postController.getEndPaging()) {
                        adapterPost.addLoading();
                        postController.getPostListPaginated(new ResultListener<List<Post>>() {
                            @Override
                            public void finish(List<Post> resultado) {
                                adapterPost.removeLoading();
                                adapterPost.addPostList(resultado);
                                adapterPost.notifyDataSetChanged();
                                isLoading = false;
                            }
                        });

                    }
                }
            }
        });


    }
}











