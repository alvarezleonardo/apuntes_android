package com.ejemplo.post.controller;

import android.content.Context;

import com.ejemplo.post.dao.PostDAO;
import com.ejemplo.post.model.Post;

import java.util.List;

import util.HTTPConnectionManager;
import util.ResultListener;

/**
 * Created by digitalhouse on 6/06/16.
 */
public class PostController {

    private Integer offset = 0;
    private static final Integer LIMIT =  10;
    private Boolean endPaging = false;

    public Boolean getEndPaging() {
        return endPaging;
    }

    //El controller se encarga de pedirle la lista al DAO y luego le avisa al listener de la vista que ya esta disponible para que la use.
    public void getPostListPaginated(final ResultListener<List<Post>> listenerFromView) {

        PostDAO postDAO = new PostDAO();

            //SI ESTOY ONLINE PIDO AL DAO QUE ME TRAIGA LAS COSAS DESDE EL SERVICIO
            postDAO.getPostsPaginated(new ResultListener<List<Post>>() {
                @Override
                public void finish(List<Post> unaPagina) {

                    if(unaPagina.size() < LIMIT){
                        endPaging = true;
                    }

                    offset = offset + LIMIT;

                    listenerFromView.finish(unaPagina);
                }
            },offset,LIMIT);
        }
}
