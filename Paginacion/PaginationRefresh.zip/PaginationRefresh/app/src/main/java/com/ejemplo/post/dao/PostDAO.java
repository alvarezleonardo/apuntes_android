package com.ejemplo.post.dao;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.AsyncTask;

import com.ejemplo.post.model.Post;
import com.ejemplo.post.model.PostContainer;
import com.google.gson.Gson;

import java.util.ArrayList;
import java.util.List;

import util.DAOException;
import util.HTTPConnectionManager;
import util.ResultListener;

/**
 * Created by digitalhouse on 6/06/16.
 */
public class PostDAO {



    //ESTE METODO CHEQUEA SI TIENE CONEXION DE INTERNET, EN CASO AFIRMATIVO GENERAMOS EL ASYNC TASK Y PEDIMOS EL LISTADO A LA
    //URL, EN CASO NEGATIVO PEDIMOS EL CONTENIDO A LA BASE DE DATOS.
    public void getAllPosts(final ResultListener<List<Post>> listener) {

        RetrievePostTask retrieveProductsTask = new RetrievePostTask(listener);
        retrieveProductsTask.execute();
    }

    //ESTE METODO CHEQUEA SI TIENE CONEXION DE INTERNET, EN CASO AFIRMATIVO GENERAMOS EL ASYNC TASK Y PEDIMOS EL LISTADO A LA
    //URL, EN CASO NEGATIVO PEDIMOS EL CONTENIDO A LA BASE DE DATOS.
    public void getPostsPaginated(final ResultListener<List<Post>> listener, Integer offset, Integer limit) {

        RetrievePostPaginatedTask retrieveProductsTask = new RetrievePostPaginatedTask(listener,offset, limit);
        retrieveProductsTask.execute();
    }

    //ESTA CLASE ES UNA CLASE QUE ME PERMITE GENERAR UNA TAREA ASINCRONICA. ES DECIR, ESTA TAREA SE EJECUTARA
    // INDEPENDIENTEMENTE DE LO QUE ESTE HACIENDO COMO ACTIVIDAD PRINCIPAL
    class RetrievePostPaginatedTask extends AsyncTask<String, Void, List<Post>> {

        private ResultListener<List<Post>> listener;

        //Aca voy a guardar el offset y el limit que me van a pasar para hacer el pedido al servicio
        private Integer offset;

        private Integer limit;

        public RetrievePostPaginatedTask(ResultListener<List<Post>> listener,
                                         Integer offset, Integer limit) {
            this.listener = listener;
            this.offset = offset;
            this.limit = limit;
        }

        //Esto método se ejecuta mientras sigue corriendo la tarea principal. Aqui lo que haremos es conectarnos
        // al servicio y descargar la lista.
        @Override
        protected List<Post> doInBackground(String... params) {

            HTTPConnectionManager connectionManager = new HTTPConnectionManager();
            String input = null;

            try {

                Thread.sleep(5000);


                //ACA LE CONCATENO AL PEDIDO EL OFFSET
                input = connectionManager.getRequestString("http://blooming-garden-41675.herokuapp.com/posts/paginated?offset="+offset+"&limit=" + limit);
            } catch (Exception e) {
                e.printStackTrace();
            }

            Gson gson = new Gson();
            PostContainer postContainer = gson.fromJson(input, PostContainer.class);

            return postContainer.getResults();
        }

        //Una vez terminado el procesamiento, le avisamos al listener que ya tiene la lista disponible.
        @Override
        protected void onPostExecute(List<Post>posts) {

            this.listener.finish(posts);
        }
    }

    //ESTA CLASE ES UNA CLASE QUE ME PERMITE GENERAR UNA TAREA ASINCRONICA. ES DECIR, ESTA TAREA SE EJECUTARA
// INDEPENDIENTEMENTE DE LO QUE ESTE HACIENDO COMO ACTIVIDAD PRINCIPAL
    class RetrievePostTask extends AsyncTask<String, Void, List<Post>> {

        private ResultListener<List<Post>> listener;

        public RetrievePostTask(ResultListener<List<Post>> listener) {
            this.listener = listener;
        }

        //Esto método se ejecuta mientras sigue corriendo la tarea principal. Aqui lo que haremos es conectarnos
        // al servicio y descargar la lista.
        @Override
        protected List<Post> doInBackground(String... params) {
            try {
                Thread.sleep(5000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }


            HTTPConnectionManager connectionManager = new HTTPConnectionManager();
            String input = null;

            try {
                input = connectionManager.getRequestString("http://blooming-garden-41675.herokuapp.com/posts/");
            } catch (DAOException e) {
                e.printStackTrace();
            }

            Gson gson = new Gson();
            PostContainer postContainer = gson.fromJson(input, PostContainer.class);

            return postContainer.getResults();
        }

        //Una vez terminado el procesamiento, le avisamos al listener que ya tiene la lista disponible.
        @Override
        protected void onPostExecute(List<Post> productList) {

            this.listener.finish(productList);
        }
    }



}




















