package com.ejemplo.post.view;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import com.ejemplo.post.R;
import com.ejemplo.post.model.Post;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by andres on 22/06/16.
 */
public class AdapterPost extends RecyclerView.Adapter{

    private List<Post> postList;
    private Context context;

    //IDENTIFICADORES DE TIPOS DE VISTA
    private static final Integer VIEW_TYPE_LOADING = 1;
    private static final Integer VIEW_TYPE_ITEM = 0;


    public AdapterPost(Context context) {

        this.context = context;
        this.postList = new ArrayList<>();
    }

    public void setPostList(List<Post> postList) {
        this.postList = postList;
    }

    public void addPostList(List<Post> postList) {
        this.postList.addAll(postList);
    }

    public void addLoading(){
        postList.add(null);
        notifyDataSetChanged();
    }

    public void removeLoading(){
        postList.remove(postList.size()-1);
        notifyDataSetChanged();
    }

    @Override
    public int getItemViewType(int position) {
        if(postList.get(position) == null){
            return VIEW_TYPE_LOADING;
        }else {
            return VIEW_TYPE_ITEM;
        }
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        if(viewType == VIEW_TYPE_ITEM){

            View view = LayoutInflater.from(context).inflate(R.layout.recycler_view_detalle, parent, false);
            return new PostViewHolder(view);
        }

        if(viewType == VIEW_TYPE_LOADING){

            View view = LayoutInflater.from(context).inflate(R.layout.recycler_view_progress_bar, parent, false);
            return new LoadingViewHolder(view);
        }
        return null;
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {

        if(holder instanceof PostViewHolder){
            Post aPost = postList.get(position);
            PostViewHolder unTitularViewHolder = (PostViewHolder) holder;
            unTitularViewHolder.bindPost(aPost, context);
        }
        if(holder instanceof LoadingViewHolder){
            LoadingViewHolder loadingViewHolder = (LoadingViewHolder)holder;
            loadingViewHolder.startAnimation();
        }
    }

    @Override
    public int getItemCount() {
        return postList.size();
    }

    private static class PostViewHolder extends RecyclerView.ViewHolder{

        private TextView textViewId;
        private TextView textViewTitulo;
        private TextView textViewBody;
        private ImageView imageViewThumbnail;

        public PostViewHolder(View itemView) {
            super(itemView);
            textViewId = (TextView) itemView.findViewById(R.id.textViewId);
            textViewTitulo = (TextView) itemView.findViewById(R.id.textViewTitulo);
            textViewBody = (TextView) itemView.findViewById(R.id.textViewBody);
            imageViewThumbnail = (ImageView) itemView.findViewById(R.id.imageViewThumbnail);
        }

        public void bindPost(Post aPost, Context context){
            textViewId.setText(aPost.getID());
            textViewTitulo.setText(aPost.getTitle());
            textViewBody.setText(aPost.getBody());
            Picasso.with(context).load("https://upload.wikimedia.org/wikipedia/commons/thumb/1/12/User_icon_2.svg/2000px-User_icon_2.svg.png").error(R.drawable.offlineuser).into(imageViewThumbnail);
        }
    }

    private class LoadingViewHolder extends  RecyclerView.ViewHolder{

        private ProgressBar progressBar;

        public LoadingViewHolder(View itemView) {
            super(itemView);
            progressBar = (ProgressBar) itemView.findViewById(R.id.progressBar);
        }

        public void startAnimation(){
            progressBar.setIndeterminate(true);
        }
    }
}









