package com.example.digitalhouse.myapplication;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class FragmentColor extends Fragment {

    public static final String TITULO = "titulo";
    public static final String COLOR = "color";
    public static final String NUMERO_FRAGMENT = "numeroDeFragment";

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    private String titulo;

    private int numeroDeFragment;

    public static FragmentColor dameUnFragment(int numeroDeFragment, String title, int color) {
        FragmentColor fragmentFirst = new FragmentColor();
        Bundle args = new Bundle();
        args.putString(TITULO, title);
        args.putInt(COLOR, color);
        args.putInt(NUMERO_FRAGMENT,numeroDeFragment);
        fragmentFirst.setArguments(args);
        fragmentFirst.setTitulo(title);
        return fragmentFirst;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View fragmentView = inflater.inflate(R.layout.fragment_blank, container, false);

        Bundle unBundle = getArguments();
        String unTitulo = unBundle.getString(TITULO);
        int unColor = getResources().getColor(unBundle.getInt(COLOR));
        this.numeroDeFragment = unBundle.getInt(NUMERO_FRAGMENT);

        ImageView imageView = (ImageView)fragmentView.findViewById(R.id.fragment_imagen_fondo);
        TextView tituloView = (TextView) fragmentView.findViewById(R.id.fragment_titulo);

        tituloView.setText(unTitulo);
        imageView.setBackgroundColor(unColor);
        Toast.makeText(getActivity(),"Fragment "+this.numeroDeFragment+" inflado",Toast.LENGTH_LONG).show();

        return fragmentView;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        Toast.makeText(getActivity(),"Fragment "+this.numeroDeFragment+" destruido",Toast.LENGTH_LONG).show();
    }
}
