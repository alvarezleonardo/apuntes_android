package com.example.digitalhouse.myapplication;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentStatePagerAdapter;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by digitalHouse on 6/1/16.
 */
public class MiFragmentPageAdapter extends FragmentStatePagerAdapter{
    private List<FragmentColor> listaFragments;

    public MiFragmentPageAdapter(FragmentManager fm) {
        super(fm);
        this.listaFragments = new ArrayList<>();
        this.listaFragments.add(FragmentColor.dameUnFragment(0, "Titulo 0", R.color.azul));
        this.listaFragments.add(FragmentColor.dameUnFragment(1, "Titulo 1", R.color.rojo));
        this.listaFragments.add(FragmentColor.dameUnFragment(2, "Titulo 2", R.color.verde));
        this.listaFragments.add(FragmentColor.dameUnFragment(3, "Titulo 3", R.color.colorPrimary));
        this.listaFragments.add(FragmentColor.dameUnFragment(4, "Titulo 4", R.color.rojo));
        this.listaFragments.add(FragmentColor.dameUnFragment(5, "Titulo 5", R.color.verde));
        this.listaFragments.add(FragmentColor.dameUnFragment(0, "Titulo 0", R.color.azul));
        this.listaFragments.add(FragmentColor.dameUnFragment(1, "Titulo 1", R.color.rojo));
        this.listaFragments.add(FragmentColor.dameUnFragment(2, "Titulo 2", R.color.verde));
        this.listaFragments.add(FragmentColor.dameUnFragment(3, "Titulo 3", R.color.colorPrimary));
        this.listaFragments.add(FragmentColor.dameUnFragment(4, "Titulo 4", R.color.rojo));
        this.listaFragments.add(FragmentColor.dameUnFragment(5, "Titulo 5", R.color.verde));

    }

    @Override
    public Fragment getItem(int position) {
       return this.listaFragments.get(position);
    }

    @Override
    public int getCount() {
        return this.listaFragments.size();
    }

    @Override
    public CharSequence getPageTitle(int position) {
        return this.listaFragments.get(position).getTitulo();
    }
}
















