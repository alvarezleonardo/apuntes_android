package digitalhouse.android.glideterminado;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.resource.drawable.GlideDrawable;
import com.bumptech.glide.request.RequestListener;
import com.bumptech.glide.request.target.Target;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ImageView imageView = (ImageView)findViewById(R.id.imageView);

        Glide.with(this).load("http://inthecheesefactory.com/uploads/source/glidepicasso/cover.jpg").into(imageView);


/* USO DE GLIDE CON UNA IMAGEN POR DEFAULT
        Glide.with(this).load("http://inthecheesefactory.com/uploads/source/glidepicasso/cover.jpg").placeholder(R.drawable.waiting).into(imageView);
*/

    /* USO AVANZADO DE GLIDE CON LISTENER
            Glide.with(this).
                    load("http://inthecheesefactory.com/uploads/source/glidepicasso/cover.jpg").
                    listener(new RequestListener<String, GlideDrawable>() {
                        @Override
                        public boolean onException(Exception e, String model, Target<GlideDrawable> target, boolean isFirstResource) {
                            Toast.makeText(MainActivity.this, "Aca hubo un error", Toast.LENGTH_SHORT).show();
                            return false;
                        }

                        @Override
                        public boolean onResourceReady(GlideDrawable resource, String model, Target<GlideDrawable> target, boolean isFromMemoryCache, boolean isFirstResource) {
                            Toast.makeText(MainActivity.this, "Salio todo bien", Toast.LENGTH_SHORT).show();
                            return false;
                        }
                    }).
                    into(imageView);
    */
    }
}
