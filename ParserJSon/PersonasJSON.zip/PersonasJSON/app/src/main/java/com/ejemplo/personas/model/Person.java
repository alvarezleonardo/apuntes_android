package com.ejemplo.personas.model;

/**
 * Created by digitalhouse on 6/06/16.
 */
public class Person {

}
