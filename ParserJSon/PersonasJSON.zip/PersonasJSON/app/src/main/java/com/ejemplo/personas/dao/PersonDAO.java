package com.ejemplo.personas.dao;

import android.content.Context;
import android.content.res.AssetManager;
import android.util.Log;
import android.util.Xml;

import com.ejemplo.personas.model.Person;

import org.xmlpull.v1.XmlPullParser;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by digitalhouse on 6/06/16.
 */
public class PersonDAO {

    public Person getPerson(Context context){
        return null;
    }

}
